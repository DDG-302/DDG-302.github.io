from fastapi import FastAPI, Body
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from module.MSG_CALL_BACK import MSG_CALL_BACK # 引入模型类
from business.router import Router # 引入路由


app = FastAPI()
# 解决跨域
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

@app.post('/')
def read_model(item:MSG_CALL_BACK = Body(...)):   
    Router.handle_post(item) # 将接收到的消息转交给路由处理
    return {"status":1}

if __name__ == "__main__":   
    uvicorn.run(app = app, host = "0.0.0.0", port = "8000")