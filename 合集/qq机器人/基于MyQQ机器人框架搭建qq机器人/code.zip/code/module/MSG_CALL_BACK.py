from pydantic import BaseModel


class MSG_CALL_BACK(BaseModel):   
    MQ_robot: str
    MQ_type: int
    MQ_type_sub: int
    MQ_fromID: str
    MQ_fromQQ: str
    MQ_passiveQQ: str
    MQ_msg: str
    MQ_msgSeq: str
    MQ_msgID: str
    MQ_msgData: str
    MQ_timestamp: str