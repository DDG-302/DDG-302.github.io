import urllib.parse
import urllib.request
import requests


class MsgSender:
    def __init__(self) -> None:
        # 分别是MyQQ中设置的两个参数
        self.httpapi_token = "114514"
        self.httpapi_url = "http://localhost:10087/MyQQHTTPAPI"
        pass
    
    def send_pure_text_msg_2_person(self, target_qq:str, msg:str, robot_qq:str):
        Values = {
            "function" : "Api_SendMsg",
            "token" : self.httpapi_token,
            "c1" : robot_qq,
            "c2" : "1",
            "c3" : "",
            "c4" : target_qq,
            "c5" : msg
        }
        data = urllib.parse.urlencode(Values).encode("utf-8") # 转码
        rq = requests
        rq = requests.get(self.httpapi_url, params=Values) # 发送请求
        print(rq.content.decode("utf-8")) # 打印服务器返回值