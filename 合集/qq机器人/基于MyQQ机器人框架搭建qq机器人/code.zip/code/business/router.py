from module.MSG_CALL_BACK import MSG_CALL_BACK
from urllib.parse import unquote
from business.msg_sender import MsgSender


class Router:
    def __init__(self):
        pass

    @staticmethod
    def handle_post(item:MSG_CALL_BACK):
        print("发送消息的qq号：", item.MQ_fromQQ)
        received_msg = unquote(item.MQ_msg)
        print("消息为：", received_msg) # 打印收到的具体消息
        print("MQ_type：", item.MQ_type) # 打印消息类型
        if(item.MQ_type == 1):
            # 如果不为1说明不是好友私聊，不做任何处理
            response_msg = "收到了你发的消息，你发的消息是：" + received_msg
            current_robot_qq = "" # 填入你的机器人qq号，目前先将其写死在程序中
            MsgSender().send_pure_text_msg_2_person(item.MQ_fromQQ, response_msg , current_robot_qq)